CREATE DATABASE  IF NOT EXISTS `theater` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `theater`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: theater
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `charge`
--

DROP TABLE IF EXISTS `charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `charge` (
  `charge_id` int NOT NULL AUTO_INCREMENT,
  `kind` varchar(15) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `type` varchar(3) DEFAULT NULL,
  `cost` int DEFAULT NULL,
  `day` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`charge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charge`
--

LOCK TABLES `charge` WRITE;
/*!40000 ALTER TABLE `charge` DISABLE KEYS */;
INSERT INTO `charge` VALUES (1,'일반(2D)','06:00:00','일반',10000,'평일'),(2,'일반(2D)','10:00:00','일반',12000,'평일'),(3,'일반(2D)','13:00:00','일반',14000,'평일'),(4,'일반(2D)','06:00:00','일반',11000,'공휴일'),(5,'일반(2D)','10:00:00','일반',15000,'공휴일'),(6,'일반(2D)','13:00:00','일반',15000,'공휴일'),(7,'일반(2D)','06:00:00','청소년',8000,'평일'),(8,'일반(2D)','10:00:00','청소년',10000,'평일'),(9,'일반(2D)','13:00:00','청소년',11000,'평일'),(10,'일반(2D)','06:00:00','청소년',8000,'공휴일'),(11,'일반(2D)','10:00:00','청소년',12000,'공휴일'),(12,'일반(2D)','13:00:00','청소년',12000,'공휴일'),(13,'일반(3D)','06:00:00','청소년',11000,'평일'),(14,'일반(3D)','10:00:00','청소년',13000,'평일'),(15,'일반(3D)','13:00:00','청소년',13000,'평일'),(16,'SWEETBOX(2D)','06:00:00','일반',12000,'평일'),(17,'SWEETBOX(2D)','10:00:00','일반',14000,'평일'),(18,'SWEETBOX(2D)','13:00:00','일반',15000,'평일'),(19,'SWEETBOX(2D)','06:00:00','일반',14000,'공휴일'),(20,'SWEETBOX(2D)','10:00:00','일반',17000,'공휴일'),(21,'SWEETBOX(2D)','13:00:00','일반',17000,'공휴일'),(22,'SWEETBOX(2D)','06:00:00','청소년',12000,'평일'),(23,'SWEETBOX(2D)','10:00:00','청소년',12000,'평일'),(24,'SWEETBOX(2D)','13:00:00','청소년',12000,'평일'),(25,'SWEETBOX(2D)','06:00:00','청소년',14000,'공휴일'),(26,'SWEETBOX(2D)','10:00:00','청소년',14000,'공휴일'),(27,'SWEETBOX(2D)','13:00:00','청소년',14000,'공휴일'),(28,'SWEETBOX(3D)','06:00:00','일반',13000,'평일'),(29,'SWEETBOX(3D)','10:00:00','일반',16000,'평일'),(30,'SWEETBOX(3D)','13:00:00','일반',17000,'평일'),(31,'SWEETBOX(3D)','06:00:00','일반',15000,'공휴일'),(32,'SWEETBOX(3D)','10:00:00','일반',20000,'공휴일'),(33,'SWEETBOX(3D)','13:00:00','일반',20000,'공휴일'),(34,'SWEETBOX(3D)','06:00:00','청소년',13000,'평일'),(35,'SWEETBOX(3D)','10:00:00','청소년',13000,'평일'),(36,'SWEETBOX(3D)','13:00:00','청소년',14000,'평일'),(37,'SWEETBOX(3D)','06:00:00','청소년',15000,'공휴일'),(38,'SWEETBOX(3D)','10:00:00','청소년',16000,'공휴일'),(39,'SWEETBOX(3D)','13:00:00','청소년',16000,'공휴일'),(40,'4DX(2D)','06:00:00','일반',14000,'평일'),(41,'4DX(2D)','10:00:00','일반',18000,'평일'),(42,'4DX(2D)','13:00:00','일반',19000,'평일'),(43,'4DX(2D)','06:00:00','일반',15000,'공휴일'),(44,'4DX(2D)','10:00:00','일반',20000,'공휴일'),(45,'4DX(2D)','13:00:00','일반',20000,'공휴일'),(46,'4DX(2D)','06:00:00','청소년',12000,'평일'),(47,'4DX(2D)','10:00:00','청소년',12000,'평일'),(48,'4DX(2D)','13:00:00','청소년',13000,'평일'),(49,'4DX(2D)','06:00:00','청소년',13000,'공휴일'),(50,'4DX(2D)','10:00:00','청소년',13000,'공휴일'),(51,'4DX(2D)','13:00:00','청소년',13000,'공휴일'),(52,'4DX(3D)','06:00:00','일반',17000,'평일'),(53,'4DX(3D)','10:00:00','일반',22000,'평일'),(54,'4DX(3D)','13:00:00','일반',23000,'평일'),(55,'4DX(3D)','06:00:00','일반',18000,'공휴일'),(56,'4DX(3D)','10:00:00','일반',24000,'공휴일'),(57,'4DX(3D)','13:00:00','일반',24000,'공휴일'),(58,'4DX(3D)','06:00:00','청소년',15000,'평일'),(59,'4DX(3D)','10:00:00','청소년',15000,'평일'),(60,'4DX(3D)','13:00:00','청소년',16000,'평일'),(61,'4DX(3D)','06:00:00','청소년',16000,'공휴일'),(62,'4DX(3D)','10:00:00','청소년',17000,'공휴일'),(63,'4DX(3D)','13:00:00','청소년',17000,'공휴일'),(64,'ULTRA 4DX(2D)','06:00:00','일반',16000,'평일'),(65,'ULTRA 4DX(2D)','10:00:00','일반',20000,'평일'),(66,'ULTRA 4DX(2D)','13:00:00','일반',21000,'평일'),(67,'ULTRA 4DX(2D)','06:00:00','일반',17000,'공휴일'),(68,'ULTRA 4DX(2D)','10:00:00','일반',23000,'공휴일'),(69,'ULTRA 4DX(2D)','13:00:00','일반',23000,'공휴일'),(70,'ULTRA 4DX(2D)','06:00:00','청소년',14000,'평일'),(71,'ULTRA 4DX(2D)','10:00:00','청소년',14000,'평일'),(72,'ULTRA 4DX(2D)','13:00:00','청소년',15000,'평일'),(73,'ULTRA 4DX(2D)','06:00:00','청소년',15000,'공휴일'),(74,'ULTRA 4DX(2D)','10:00:00','청소년',15000,'공휴일'),(75,'ULTRA 4DX(2D)','13:00:00','청소년',16000,'공휴일'),(76,'ULTRA 4DX(3D)','06:00:00','일반',19000,'평일'),(77,'ULTRA 4DX(3D)','10:00:00','일반',25000,'평일'),(78,'ULTRA 4DX(3D)','13:00:00','일반',26000,'평일'),(79,'ULTRA 4DX(3D)','06:00:00','일반',20000,'공휴일'),(80,'ULTRA 4DX(3D)','10:00:00','일반',27000,'공휴일'),(81,'ULTRA 4DX(3D)','13:00:00','일반',27000,'공휴일'),(82,'ULTRA 4DX(3D)','06:00:00','청소년',16000,'평일'),(83,'ULTRA 4DX(3D)','10:00:00','청소년',16000,'평일'),(84,'ULTRA 4DX(3D)','13:00:00','청소년',17000,'평일'),(85,'ULTRA 4DX(3D)','06:00:00','청소년',17000,'공휴일'),(86,'ULTRA 4DX(3D)','10:00:00','청소년',18000,'공휴일'),(87,'ULTRA 4DX(3D)','13:00:00','청소년',18000,'공휴일');
/*!40000 ALTER TABLE `charge` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-19  9:17:50
