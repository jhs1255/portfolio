CREATE DATABASE  IF NOT EXISTS `theater` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `theater`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: theater
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `movie_id` int NOT NULL,
  `title` tinytext,
  `url` text,
  `running_time` time DEFAULT NULL,
  `age` int DEFAULT NULL,
  PRIMARY KEY (`movie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (20224666,'파일럿','https://www.kobis.or.kr/common/mast/movie/2024/07/thumb_x192/thn_a901202adef143bd8cd3a54fd90e3fa8.jpg','01:50:58',12),(20233213,'여름이 끝날 무렵의 라트라비아타','https://www.kobis.or.kr/common/mast/movie/2024/08/thumb_x192/thn_8fabcffce0ef494fa8c2d0dd2ab8434c.jpg','01:55:06',0),(20234437,'코마다 위스키 패밀리','https://www.kobis.or.kr/common/mast/movie/2024/08/thumb_x192/thn_0908c8e62f4b4c769ef821387f461286.jpg','01:31:08',12),(20234709,'장손','https://www.kobis.or.kr/common/mast/movie/2024/08/thumb_x192/thn_0aa34c0818ea4f9984b3f90e92ff1a58.jpg','02:00:35',12),(20239670,'베테랑2','https://www.kobis.or.kr/common/mast/movie/2024/08/thumb_x192/thn_886a61eb398d4cedb346d9ffbf3345c3.jpg','01:58:03',15),(20240669,'비틀쥬스 비틀쥬스','https://www.kobis.or.kr/common/mast/movie/2024/08/thumb_x192/thn_5f1b0bd6ce174d05aac8e86056519627.jpg','01:44:33',12),(20240925,'안녕, 할부지','https://www.kobis.or.kr/common/mast/movie/2024/09/thumb_x192/thn_2e941900f0fd4b788e6af381b38ebbcb.jpg','01:34:32',0),(20241337,'트위스터스','https://www.kobis.or.kr/common/mast/movie/2024/09/thumb_x192/thn_2e941900f0fd4b788e6af381b38ebbcb.jpg','02:02:13',12),(20242794,'임영웅 | 아임 히어로 더 스타디움','https://www.kobis.or.kr/common/mast/movie/2024/07/thumb_x192/thn_4cc5fdaed5534f5b90e54828e49eb726.jpg','01:48:22',0),(20249188,'에이리언- 로물루스','https://www.kobis.or.kr/common/mast/movie/2024/08/thumb_x192/thn_32c84ebea97c4f48b52515ebf6e81aec.jpg','01:58:51',15),(20249733,'사랑의 하츄핑','https://www.kobis.or.kr/common/mast/movie/2024/07/thumb_x192/thn_802e82bdf0af47fcbdab6d012aeac2bb.jpg','01:26:00',0);
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-19  9:17:51
